<!-- footer-->
<div class="footer">
    <div class="no-gutters">
        <div class="col-auto mx-auto">
            <div class="row no-gutters justify-content-center">
                <div class="col-auto">
                    <a href="index.html" class="btn btn-link-default active">
                        <i class="material-icons">home</i>
                    </a>
                </div>
                <div class="col-auto">
                    <a href="statistics.html" class="btn btn-link-default">
                        <i class="material-icons">insert_chart_outline</i>
                    </a>
                </div>
                <div class="col-auto">
                    <a href="wallet.html" class="btn btn-link-default">
                        <i class="material-icons">account_balance_wallet</i>
                    </a>
                </div>
                <div class="col-auto">
                    <a href="transactions.html" class="btn btn-link-default">
                        <i class="material-icons">widgets</i>
                    </a>
                </div>
                <div class="col-auto">
                    <a href="profile.html" class="btn btn-link-default">
                        <i class="material-icons">account_circle</i>
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- footer ends-->

</div>