<div class="wrapper">
    <div class="row no-gutters login-row">
        <div class="col align-self-center px-3 text-center">
            <img src="<?= base_url(); ?>assets/img/information-graphics-otp.png" alt="logo" class="mw-100">
            <p class="mt-4 d-block text-secondary">
                403 Forbidden
            <p>Directory access is forbidden.
            </p>

        </div>
    </div>

    <!-- login buttons -->
    <div class="row mx-0 bottom-button-container">
        <div class="col">
            <a href="<?= base_url('auth/logout'); ?>" class="btn btn-default btn-lg btn-rounded shadow btn-block">Back</a>
        </div>
    </div>
    <!-- login buttons -->
</div>