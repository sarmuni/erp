Thanks for downloading this template from Bootstrap24.com

Template Name: Nura Admin 4 (for Bootstrap 4)
URL: https://bootstrap24.com/template/nura-admin-4-free-bootstrap-admin-template
Author: Bootstrap24.com
License: https://bootstrap24.com/license/
